function evalue(){
    var input = document.getElementById("Nombre");
    var value = input.value;
    alert("Bienvenido:" + value);
}